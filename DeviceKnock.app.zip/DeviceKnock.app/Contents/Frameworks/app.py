#!/usr/bin/env python3
"""
DeviceKnock — Web Edition
-----------------------------
A single-file Flask app that:
  - Pings a configurable list of devices on a background thread
  - Lets you create/rename/delete device TYPES (categories)
  - Gives each type its own page to add/remove/reassign devices
  - Shows a dashboard listing ONLY offline devices (for at-a-glance
    triage), plus a total/online/offline summary
  - Sends an email alert when a device goes offline (and optionally
    when it comes back online)

Run:
    pip install -r requirements.txt
    python3 app.py

Then visit http://<server-ip>:5050 in a browser.

Config lives in config.json (created automatically on first run).
Fill in your SMTP details there before relying on email alerts.
"""

import argparse
import csv
import getpass
import io
import json
import logging
import os
import platform
import re
import secrets
import smtplib
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from email.mime.text import MIMEText
from functools import wraps
from logging.handlers import RotatingFileHandler

from flask import (Flask, request, redirect, url_for, render_template_string,
                    session, abort, jsonify)
from werkzeug.security import generate_password_hash, check_password_hash

def _get_data_dir():
    """Where config.json, monitor.log, etc. actually live.

    When running as a plain script (the IT/sysadmin CLI version), keep
    the original behavior: files live in the current working directory,
    since that's the folder the person deliberately set up and expects
    to find everything in.

    When running as a PyInstaller-frozen packaged app (the double-click
    consumer product), use a proper per-user OS data directory instead.
    A GUI app's working directory isn't reliably the install folder
    (especially true for a macOS .app bundle, where writing inside the
    bundle itself is also the wrong place to put mutable data).
    """
    if getattr(sys, "frozen", False):
        if sys.platform == "win32":
            base = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))
        elif sys.platform == "darwin":
            base = os.path.expanduser("~/Library/Application Support")
        else:
            base = os.path.expanduser("~/.local/share")
        data_dir = os.path.join(base, "DeviceKnock")
        os.makedirs(data_dir, exist_ok=True)
        return data_dir
    return "."


_DATA_DIR = _get_data_dir()
CONFIG_FILE = os.path.join(_DATA_DIR, "config.json")
LOG_FILE = os.path.join(_DATA_DIR, "monitor.log")
LICENSE_FILE = os.path.join(_DATA_DIR, "license.json")
UNCATEGORIZED = "Uncategorized"

# Free tier: unlicensed installs can monitor up to this many devices.
# Entering a valid license key removes this limit entirely.
FREE_TIER_DEVICE_LIMIT = 5

# Where customers go to buy a license. Only ever shown to admins, and only
# while unlicensed — disappears automatically once a valid key is activated.
LICENSE_PURCHASE_URL = "https://www.paypal.com/ncp/payment/D2A8UMX48J7HE"


def load_license():
    """Returns the licensed customer name, or None if unlicensed/free tier.

    Only the packaged/frozen consumer product has a licensing concept at
    all — the plain CLI version (what IT/sysadmin users run directly
    with `python3 app.py`) is always treated as fully licensed.
    """
    if not getattr(sys, "frozen", False):
        return "IT Tool"
    if not os.path.exists(LICENSE_FILE):
        return None
    try:
        from license_manager import validate_key, get_machine_id
        with open(LICENSE_FILE) as f:
            data = json.load(f)
        ok, msg = validate_key(data.get("key", ""), current_machine_id=get_machine_id(_DATA_DIR))
        return msg if ok else None
    except Exception:
        return None


def save_license(key):
    with open(LICENSE_FILE, "w") as f:
        json.dump({"key": key}, f)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5MB cap on uploads (CSV imports)

# In-memory status cache: host -> {"name":.., "up": bool/None, "last_change": str}
status_lock = threading.Lock()
status = {}


# ---------------------------------------------------------------------
# Config handling
# ---------------------------------------------------------------------
def default_config():
    return {
        "types": ["Network", "Computer", "Phone-Tablet", "IoT / Smart Home", "Printer", "Server"],
        "devices": [
            {"name": "Router", "host": "192.168.1.1", "type": "Network"}
        ],
        "check_interval_seconds": 5,
        "ping_timeout_seconds": 1,
        "max_concurrent_pings": 200,
        "offline_alert_delay_seconds": 60,
        "web_host": "0.0.0.0",
        "web_port": 5050,
        "users": [
            {"username": "admin", "password_hash": None, "role": "admin"}
        ],
        "secret_key": None,
        "csrf_token": None,
        "email": {
            "enabled": False,
            "smtp_server": "smtp.gmail.com",
            "smtp_port": 587,
            "username": "your_email@gmail.com",
            "password": "your_app_password",
            "from_addr": "your_email@gmail.com",
            "to_addr": "your_email@gmail.com",
            "notify_on_recovery": True
        }
    }


def load_config():
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w") as f:
            json.dump(default_config(), f, indent=2)
    with open(CONFIG_FILE) as f:
        cfg = json.load(f)

    changed = False
    if "types" not in cfg:
        cfg["types"] = ["Network", "Computer", "Phone-Tablet", "IoT / Smart Home", "Printer", "Server"]
        changed = True
    if "max_concurrent_pings" not in cfg:
        cfg["max_concurrent_pings"] = 200
        changed = True
    if "offline_alert_delay_seconds" not in cfg:
        cfg["offline_alert_delay_seconds"] = 60
        changed = True
    if "web_host" not in cfg:
        cfg["web_host"] = "0.0.0.0"
        changed = True
    if "web_port" not in cfg:
        cfg["web_port"] = 5050
        changed = True
    if "secret_key" not in cfg or not cfg["secret_key"]:
        cfg["secret_key"] = secrets.token_hex(32)
        changed = True
    if "csrf_token" not in cfg or not cfg["csrf_token"]:
        cfg["csrf_token"] = secrets.token_hex(16)
        changed = True
    if "auth" in cfg and "users" not in cfg:
        # Migrate from the old single-admin format
        old_auth = cfg.pop("auth")
        cfg["users"] = [{
            "username": old_auth.get("username", "admin"),
            "password_hash": old_auth.get("password_hash"),
            "role": "admin"
        }]
        changed = True
    if "users" not in cfg:
        cfg["users"] = [{"username": "admin", "password_hash": None, "role": "admin"}]
        changed = True

    # No auto-generated password here anymore — if no user has a
    # password_hash yet, enforce_setup() (below) redirects every request
    # to a web-based first-run screen where the person creates their own
    # admin username and password directly.

    # Backfill "type" for devices saved before categories existed, and
    # make sure every device's type still exists in the types list.
    for d in cfg.get("devices", []):
        if "type" not in d or not d["type"] or d["type"] not in cfg["types"]:
            d["type"] = UNCATEGORIZED
            changed = True

    if changed:
        save_config(cfg)

    app.secret_key = cfg["secret_key"]
    return cfg


def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)


_logger = logging.getLogger("device_monitor")
_logger.setLevel(logging.INFO)
_handler = RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5)
_handler.setFormatter(logging.Formatter("[%(asctime)s] %(message)s", "%Y-%m-%d %H:%M:%S"))
_logger.addHandler(_handler)
_console_handler = logging.StreamHandler()
_console_handler.setFormatter(logging.Formatter("[%(asctime)s] %(message)s", "%Y-%m-%d %H:%M:%S"))
_logger.addHandler(_console_handler)


def log(msg):
    _logger.info(msg)


# ---------------------------------------------------------------------
# Ping + email
# ---------------------------------------------------------------------
def _no_window_kwargs():
    """On Windows, spawning a subprocess (even from a windowed/no-console
    app) still briefly flashes a console window for that child process
    unless explicitly suppressed. This is purely cosmetic but very
    noticeable when it happens every few seconds for every device."""
    if platform.system().lower() == "windows":
        return {"creationflags": subprocess.CREATE_NO_WINDOW}
    return {}


def ping(host, timeout):
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", "1", "-w", str(int(timeout * 1000)), host]
    else:
        cmd = ["ping", "-c", "1", "-W", str(int(timeout)), host]
    try:
        result = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, timeout=timeout + 2,
                                 **_no_window_kwargs())
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False
    except FileNotFoundError:
        log("ERROR: 'ping' command not found on this system.")
        return False


MAC_PATTERN = re.compile(r"([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}")


def normalize_mac(mac_str):
    """Normalize a user-entered MAC to UPPERCASE:WITH:COLONS, accepting
    colons, hyphens, or no separator at all. Returns "" if input is empty
    or doesn't look like a MAC at all (left as free text rather than
    rejected, so a typo doesn't block saving the rest of the form)."""
    mac_str = mac_str.strip()
    if not mac_str:
        return ""
    cleaned = mac_str.replace("-", ":").upper()
    if MAC_PATTERN.fullmatch(cleaned):
        return cleaned
    # Also accept no separators at all, e.g. "AABBCCDDEEFF"
    compact = re.sub(r"[^0-9A-Fa-f]", "", mac_str)
    if len(compact) == 12:
        return ":".join(compact[i:i + 2] for i in range(0, 12, 2)).upper()
    return mac_str  # not recognized as a MAC — keep as-is, don't silently drop it


def parse_devices_csv(text, default_type, existing_hosts, existing_types):
    """Parse CSV text into a list of new device dicts.

    Expected columns (case-insensitive): name, host — required.
    mac, type — optional. Any row missing name or host is skipped.
    A row whose host already exists (in existing_hosts, or earlier in
    the same file) is skipped as a duplicate. A "type" value not
    already known gets created automatically, so importing a fresh
    inventory doesn't require pre-creating every category by hand.

    Returns (new_devices, new_types, stats) — pure function, doesn't
    touch global state, so it's easy to unit test directly.
    """
    stats = {"imported": 0, "skipped_duplicate": 0, "skipped_invalid": 0, "rows_total": 0}
    new_devices = []
    new_types = []
    seen_hosts = set(existing_hosts)
    known_types = set(existing_types)

    if text.startswith("\ufeff"):
        text = text[1:]  # strip UTF-8 BOM (common in Excel-exported CSVs)

    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        return new_devices, new_types, stats

    # Case-insensitive header matching (Name, NAME, name all work)
    header_map = {fn.strip().lower(): fn for fn in reader.fieldnames if fn}

    def get_field(row, field_name):
        actual_key = header_map.get(field_name)
        if actual_key is None:
            return ""
        return (row.get(actual_key) or "").strip()

    for row in reader:
        stats["rows_total"] += 1
        name = get_field(row, "name")
        host = get_field(row, "host")
        mac_raw = get_field(row, "mac")
        row_type = get_field(row, "type") or default_type

        if not name or not host:
            stats["skipped_invalid"] += 1
            continue
        if host in seen_hosts:
            stats["skipped_duplicate"] += 1
            continue

        seen_hosts.add(host)
        if row_type not in known_types:
            known_types.add(row_type)
            new_types.append(row_type)

        device = {"name": name, "host": host, "type": row_type}
        mac = normalize_mac(mac_raw)
        if mac:
            device["mac"] = mac
        new_devices.append(device)
        stats["imported"] += 1

    return new_devices, new_types, stats


def get_mac_address(host):
    """Look up a device's MAC address via the ARP table.

    Only works for devices on the same local network segment — ARP is a
    link-layer protocol and doesn't cross routers/subnets. A device
    behind a router (most VPNs, most WAN/remote sites) will simply not
    have an ARP entry, and this correctly returns None rather than
    guessing. A successful ping to the host is normally required first,
    since that's what populates the ARP cache in the first place.

    Tries the most likely method for the current OS, with fallbacks for
    older/newer tooling (e.g. Linux distros that dropped `arp` in favor
    of `ip neigh`).
    """
    system = platform.system().lower()

    def run(cmd, timeout=3):
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                                     **_no_window_kwargs())
            return result.stdout
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            return ""

    if system == "windows":
        output = run(["arp", "-a", host])
        match = MAC_PATTERN.search(output)
        if match:
            return match.group(0).upper().replace("-", ":")
        return None

    # macOS and Linux
    output = run(["arp", "-n", host])
    match = MAC_PATTERN.search(output)
    if match:
        return match.group(0).upper()

    if system == "linux":
        # Fall back to iproute2, common on modern distros that dropped
        # net-tools (which is what provides the `arp` command).
        output = run(["ip", "neigh", "show", host])
        match = MAC_PATTERN.search(output)
        if match:
            return match.group(0).upper()

        # Last resort: read the kernel ARP table directly, no subprocess
        # needed at all.
        try:
            with open("/proc/net/arp") as f:
                for line in f.readlines()[1:]:
                    fields = line.split()
                    if len(fields) >= 4 and fields[0] == host:
                        mac = fields[3]
                        if mac != "00:00:00:00:00:00":
                            return mac.upper()
        except (FileNotFoundError, OSError):
            pass

    return None


def send_email(cfg, subject, body):
    email_cfg = cfg.get("email", {})
    if not email_cfg.get("enabled"):
        return
    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = email_cfg["from_addr"]
        msg["To"] = email_cfg["to_addr"]

        with smtplib.SMTP(email_cfg["smtp_server"], email_cfg["smtp_port"], timeout=10) as server:
            server.starttls()
            server.login(email_cfg["username"], email_cfg["password"])
            server.sendmail(email_cfg["from_addr"], [email_cfg["to_addr"]], msg.as_string())
        log(f"Email sent: {subject}")
    except Exception as e:
        log(f"ERROR sending email: {e}")


# ---------------------------------------------------------------------
# Background monitor loop
# ---------------------------------------------------------------------
def check_one_device(d, timeout, known_mac=None):
    """Ping a single device and return (device_dict, is_up, mac).
    Skips the ARP lookup entirely if a MAC is already cached for this
    device — avoids a second subprocess call every single sweep once
    we already know it (MAC addresses essentially never change)."""
    is_up = ping(d["host"], timeout)
    mac = known_mac
    if is_up and not mac:
        mac = get_mac_address(d["host"])
    return d, is_up, mac


def update_device_status(host, name, device_type, is_up, cfg, now_ts=None, mac=None):
    """Update status[host] based on a fresh ping result, handling the
    delayed-alert logic. Must be called while holding status_lock.
    Returns nothing; mutates the module-level `status` dict directly.
    `now_ts` is injectable for testing; defaults to the real clock.
    `mac`, if provided, is cached; if not provided, any previously
    known MAC for this host is preserved rather than wiped out.
    """
    if now_ts is None:
        now_ts = time.time()
    alert_delay = cfg.get("offline_alert_delay_seconds", 60)

    prev_entry = status.get(host, {})
    prev_up = prev_entry.get("up")
    offline_since = prev_entry.get("offline_since")
    alerted = prev_entry.get("alerted", False)
    known_mac = mac or prev_entry.get("mac")
    now_str = datetime.fromtimestamp(now_ts).strftime("%Y-%m-%d %H:%M:%S")

    if prev_up is None:
        # First check ever for this device — just record state,
        # don't fire any alert (nothing to compare against yet).
        log(f"{name} ({host}) initial state: {'ONLINE' if is_up else 'OFFLINE'}")
        offline_since = None if is_up else now_ts
        alerted = False

    elif is_up and not prev_up:
        # Device recovered. Only send a "back online" email if we
        # actually alerted that it went offline in the first
        # place — a blip shorter than the alert delay never got
        # announced, so there's nothing to announce recovery from.
        if alerted:
            log(f"{name} ({host}) back ONLINE")
            if cfg["email"].get("notify_on_recovery", True):
                send_email(cfg, f"[DeviceKnock] {name} ({device_type}) is back online",
                           f"{name} — Type: {device_type} — Host: {host}\n\n"
                           f"This device is responding to ping again as of {now_str}.")
        else:
            log(f"{name} ({host}) back online (brief outage, no alert was sent)")
        offline_since = None
        alerted = False

    elif not is_up:
        # Still down — whether just transitioned this tick or continuing
        # from before. Either way, check the alert threshold using
        # whatever offline_since ends up being for this tick.
        if prev_up:
            log(f"{name} ({host}) stopped responding, starting {alert_delay}s alert delay")
            offline_since = now_ts

        if not alerted and offline_since and (now_ts - offline_since) >= alert_delay:
            log(f"{name} ({host}) went OFFLINE (down for {int(now_ts - offline_since)}s)")
            since_str = datetime.fromtimestamp(offline_since).strftime("%Y-%m-%d %H:%M:%S")
            send_email(cfg, f"[DeviceKnock] {name} ({device_type}) is OFFLINE",
                       f"{name} — Type: {device_type} — Host: {host}\n\n"
                       f"This device has not responded to ping since {since_str} "
                       f"({alert_delay}s ago).")
            alerted = True
        # else: still within the grace period, or already alerted — no action.

    # else: is_up and prev_up — steady-state online, nothing to do.

    status[host] = {
        "name": name,
        "up": is_up,
        "last_change": now_str,
        "offline_since": offline_since,
        "alerted": alerted,
        "mac": known_mac,
    }


def monitor_loop():
    while True:
        sweep_start = time.time()

        cfg = load_config()
        devices = cfg.get("devices", [])
        timeout = cfg.get("ping_timeout_seconds", 1)
        interval = cfg.get("check_interval_seconds", 5)
        max_workers = max(1, cfg.get("max_concurrent_pings", 100))

        results = {}
        if devices:
            with status_lock:
                known_macs = {d["host"]: status.get(d["host"], {}).get("mac") for d in devices}
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(check_one_device, d, timeout, known_macs.get(d["host"]))
                           for d in devices]
                for future in as_completed(futures):
                    d, is_up, mac = future.result()
                    results[d["host"]] = (d, is_up, mac)

        with status_lock:
            for host in list(status.keys()):
                if not any(d["host"] == host for d in devices):
                    del status[host]

            for host, (d, is_up, mac) in results.items():
                update_device_status(host, d["name"], d.get("type", UNCATEGORIZED), is_up, cfg, mac=mac)

        sweep_duration = time.time() - sweep_start
        if sweep_duration > interval:
            log(f"WARNING: sweep of {len(devices)} device(s) took {sweep_duration:.1f}s, "
                f"longer than the {interval}s interval. Consider raising "
                f"'max_concurrent_pings' in config.json.")

        sleep_time = max(0, interval - sweep_duration)
        time.sleep(sleep_time)


# ---------------------------------------------------------------------
# Shared styles + nav
# ---------------------------------------------------------------------
BASE_STYLE = """
    body { font-family: -apple-system, Arial, sans-serif; max-width: 900px; margin: 30px auto; padding: 0 16px; color: #222; }
    h1 { font-size: 1.4rem; margin-bottom: 4px; }
    .brand-title { font-size: 2.1rem; font-weight: 800; letter-spacing: -0.03em; margin-bottom: 2px;
                   background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                   -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
                   color: #2563eb; }
    .page-heading { font-size: 1.25rem; font-weight: 600; color: #333; margin: 0 0 12px; }
    .app-footer { text-align: center; color: #999; font-size: 0.8rem; margin: 48px 0 16px; padding-top: 16px;
                  border-top: 1px solid #eee; }
    h2 { font-size: 1.05rem; margin: 28px 0 6px; color: #333; }
    table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    th, td { text-align: left; padding: 8px; border-bottom: 1px solid #eee; }
    .mac-cell { font-family: "SF Mono", Monaco, Consolas, monospace; font-size: 0.85rem; color: #555; }
    .edit-toggle-btn { background: none; border: none; color: #555; text-decoration: underline;
                       cursor: pointer; font-size: 0.8rem; padding: 2px 6px; }
    .edit-toggle-btn:hover { color: #111; }
    .cancel-btn { background: #eee; color: #444; border: none; border-radius: 4px; }
    .up { color: #1a7f37; font-weight: bold; }
    .down { color: #d1242f; font-weight: bold; }
    .unknown { color: #999; }
    form.inline { display: inline; }
    input[type=text] { padding: 6px; margin-right: 6px; }
    select { padding: 6px; margin-right: 6px; }
    button { padding: 6px 12px; cursor: pointer; }
    .add-form { margin-top: 24px; padding: 16px; background: #f6f8fa; border-radius: 8px; }
    .remove-btn { background: #d1242f; color: white; border: none; border-radius: 4px; }
    .danger-btn { background: #d1242f; color: white; border: none; border-radius: 4px; }
    .note { color: #666; font-size: 0.9rem; margin-top: 24px; }

    .summary { display: flex; gap: 12px; margin: 16px 0; }
    .stat-card { flex: 1; padding: 14px; border-radius: 8px; text-align: center; background: #f6f8fa; }
    .stat-card .num { font-size: 1.8rem; font-weight: bold; display: block; }
    .stat-card.total .num { color: #333; }
    .stat-card.online .num { color: #1a7f37; }
    .stat-card.offline .num { color: #d1242f; }
    .stat-card .label { font-size: 0.85rem; color: #666; }

    .offline-banner { background: #fdeeee; border: 1px solid #f2b8b8; border-radius: 8px; padding: 12px 16px; margin-bottom: 8px; }
    .offline-banner strong { color: #d1242f; }
    .all-clear { background: #eafbf0; border: 1px solid #b8e6c8; border-radius: 8px; padding: 24px 16px; margin-bottom: 8px; color: #1a7f37; text-align: center; font-size: 1.1rem; }

    nav.tabs { display: flex; flex-wrap: wrap; gap: 6px; margin: 14px 0 4px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
    nav.tabs a { padding: 6px 12px; border-radius: 6px; text-decoration: none; color: #333; background: #f0f0f0; font-size: 0.9rem; }
    nav.tabs a.active { background: #222; color: white; }
    .flash { background: #fff8e5; border: 1px solid #f0dca0; border-radius: 8px; padding: 10px 14px; margin: 12px 0; font-size: 0.9rem; }

    .topbar { display: flex; justify-content: space-between; align-items: center;
              background: #f6f8fa; border-radius: 8px; padding: 8px 14px; margin-bottom: 4px;
              font-size: 0.85rem; }
    .topbar-user { display: flex; align-items: center; gap: 8px; color: #333; font-weight: 500; }
    .role-badge { background: #e1e8f0; color: #444; padding: 2px 8px; border-radius: 999px;
                  font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.03em; }
    .topbar-links { display: flex; align-items: center; gap: 14px; }
    .topbar-links a { color: #555; text-decoration: none; }
    .topbar-links a:hover { text-decoration: underline; }
    .topbar-links a.active { color: #111; font-weight: 600; }
    .logout-link { color: #d1242f !important; }
"""


def topbar_html(cfg, active):
    """Account & settings — visually separate from device management."""
    settings_links = []
    if session.get("role") == "admin":
        settings_links.append('<a href="{}" class="{}">Notification Settings</a>'.format(
            url_for("email_settings"), "active" if active == "email_settings" else ""))
        settings_links.append('<a href="{}" class="{}">Users</a>'.format(
            url_for("manage_users"), "active" if active == "manage_users" else ""))
        settings_links.append('<a href="{}" class="{}">Backup &amp; Restore</a>'.format(
            url_for("backup_page"), "active" if active == "backup_page" else ""))
        settings_links.append('<a href="{}" class="{}">License</a>'.format(
            url_for("activate"), "active" if active == "activate" else ""))
    settings_links.append('<a href="{}" class="{}">My Account</a>'.format(
        url_for("my_account"), "active" if active == "my_account" else ""))

    role_badge = f'<span class="role-badge">{session.get("role", "")}</span>'
    username_display = f'<span class="topbar-username">{session.get("username", "")}</span>{role_badge}'

    return (
        '<div class="topbar">'
        f'<div class="topbar-user">{username_display}</div>'
        '<div class="topbar-links">' + "".join(settings_links) +
        f'<a href="{url_for("logout")}" class="logout-link">Log out</a>'
        '</div>'
        '</div>'
    )


def nav_html(cfg, active):
    links = [('<a href="{}" class="{}">Dashboard</a>'.format(
        url_for("index"), "active" if active == "dashboard" else ""))]
    for t in cfg["types"] + ([UNCATEGORIZED] if any(
            d["type"] == UNCATEGORIZED for d in cfg["devices"]) else []):
        links.append('<a href="{}" class="{}">{}</a>'.format(
            url_for("type_page", type_name=t),
            "active" if active == t else "",
            t
        ))
    links.append('<a href="{}" class="{}">Manage Types</a>'.format(
        url_for("manage_types"), "active" if active == "manage_types" else ""))
    return '<nav class="tabs">' + "".join(links) + "</nav>"



# ---------------------------------------------------------------------
# First-run setup (no auto-generated password — the person creates
# their own admin username/password the first time they open the app)
# ---------------------------------------------------------------------
def needs_setup(cfg):
    return not any(u.get("password_hash") for u in cfg.get("users", []))


@app.before_request
def enforce_setup():
    if request.endpoint in ("setup", "static"):
        return
    cfg = load_config()
    if needs_setup(cfg):
        return redirect(url_for("setup"))


SETUP_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: -apple-system, Arial, sans-serif; max-width: 400px; margin: 60px auto; padding: 0 16px; color: #222; }
    .brand-title { font-size: 2.1rem; font-weight: 800; letter-spacing: -0.03em; margin-bottom: 2px;
                   background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                   -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
                   color: #2563eb; }
    .page-heading { font-size: 1.1rem; font-weight: 600; color: #333; margin: 0 0 16px; }
    input[type=text], input[type=password] { width: 100%; padding: 8px; margin: 6px 0 14px; box-sizing: border-box; }
    button { width: 100%; padding: 10px; cursor: pointer; }
    .error { background: #fdeeee; border: 1px solid #f2b8b8; color: #d1242f; border-radius: 8px; padding: 10px 14px; margin-bottom: 12px; font-size: 0.9rem; }
    .note { color: #666; font-size: 0.85rem; margin-top: 16px; }
    .app-footer { text-align: center; color: #999; font-size: 0.8rem; margin: 32px 0 8px; padding-top: 12px; border-top: 1px solid #eee; }
  </style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">Welcome — let's set up your admin account</h2>
  {% if error %}<div class="error">{{ error }}</div>{% endif %}
  <form method="post">
    <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
    <label>Username</label>
    <input type="text" name="username" value="admin" required>
    <label>Password</label>
    <input type="password" name="password" required autofocus>
    <label>Confirm Password</label>
    <input type="password" name="confirm_password" required>
    <button type="submit">Create Admin Account</button>
  </form>
  <p class="note">This creates the one account you'll use to log in and manage DeviceKnock.
  You can add more accounts later from the Users page.</p>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/setup", methods=["GET", "POST"])
def setup():
    cfg = load_config()
    if not needs_setup(cfg):
        return redirect(url_for("login"))

    error = None
    if request.method == "POST":
        verify_csrf(cfg)
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        confirm_password = request.form.get("confirm_password", "").strip()

        if not username or not password:
            error = "Username and password are both required."
        elif password != confirm_password:
            error = "Passwords don't match."
        else:
            target_user = next((u for u in cfg["users"] if not u.get("password_hash")), None)
            if target_user is None:
                target_user = {"username": "", "password_hash": None, "role": "admin"}
                cfg["users"].append(target_user)
            target_user["username"] = username
            target_user["password_hash"] = generate_password_hash(password, method="pbkdf2:sha256")
            target_user["role"] = "admin"
            save_config(cfg)

            session.clear()
            session["logged_in"] = True
            session["username"] = username
            session["role"] = "admin"
            session.permanent = True
            return redirect(url_for("index"))

    return render_template_string(SETUP_TEMPLATE, error=error, csrf_token=cfg["csrf_token"])


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login", next=request.path))
        if session.get("role") != "admin":
            abort(403, description="This page is only available to admin accounts.")
        return f(*args, **kwargs)
    return wrapper


def is_licensed():
    return load_license() is not None


def get_device_limit():
    """None means unlimited (licensed or the plain CLI tool)."""
    if is_licensed():
        return None
    return FREE_TIER_DEVICE_LIMIT


ACTIVATE_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — License</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">License</h2>
  {{ topbar|safe }}
  {{ nav|safe }}

  {% if error %}<div class="flash" style="background:#fdeeee;border-color:#f2b8b8;">{{ error }}</div>{% endif %}
  {% if success %}<div class="flash" style="background:#eafbf0;border-color:#b8e6c8;">{{ success }}</div>{% endif %}

  {% if licensed_to %}
  <div class="all-clear">✓ Licensed — unlimited devices</div>
  <p style="text-align:center;">
    <button type="button" class="edit-toggle-btn" onclick="toggleKeyForm()">Change license key</button>
  </p>
  {% else %}
  <div class="offline-banner">
    <strong>Unlicensed — {{ device_count }} of {{ device_limit }} devices used (free tier).</strong>
    Enter a license key below to unlock unlimited devices.
  </div>

  <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:16px 20px;margin:16px 0;">
    <strong>How to get your license key:</strong>
    <ol style="margin:8px 0 0;padding-left:20px;line-height:1.6;">
      <li>Note this computer's <strong>Machine ID</strong> (shown below)</li>
      <li>Click "Buy a License" below to pay securely via PayPal</li>
      <li>Email your <strong>receipt</strong> AND your <strong>Machine ID</strong> to
          <a href="mailto:support@deviceknock.com">support@deviceknock.com</a></li>
      <li>We'll email your license key back within <strong>24–48 hours</strong></li>
      <li>Paste the key into the "Enter License Key" box below and click Activate</li>
    </ol>
    <p style="margin:12px 0 0;padding-top:12px;border-top:1px solid #bfdbfe;color:#1e3a8a;">
      <strong>⚠ This is a per-machine license.</strong> It will only work on the computer whose
      Machine ID you send us — make sure you send the Machine ID from the exact device you plan
      to use DeviceKnock on, not a different one.
    </p>
  </div>

  <p><a href="{{ paypal_url }}" target="_blank" rel="noopener noreferrer">Buy a License →</a></p>
  {% endif %}

  <div id="key-section" style="{{ 'display:none;' if licensed_to else '' }}">
    <h2>This Computer's Machine ID</h2>
    <p class="note">If you're purchasing a machine-locked license, send this code to whoever
    is issuing your key:</p>
    <p style="font-family:monospace;font-size:1.1rem;background:#f6f8fa;padding:10px 14px;border-radius:8px;display:inline-block;">{{ machine_id }}</p>

    <h2>Enter License Key</h2>
    <form method="post" style="max-width:420px;">
      <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
      <input type="text" name="key" placeholder="License key" style="width:100%;padding:8px;margin-bottom:10px;box-sizing:border-box;" required>
      <button type="submit">Activate</button>
    </form>
  </div>

  <script>
    function toggleKeyForm() {
      const section = document.getElementById("key-section");
      section.style.display = section.style.display === "none" ? "block" : "none";
    }
  </script>

  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/activate", methods=["GET", "POST"])
@admin_required
def activate():
    from license_manager import validate_key, get_machine_id
    cfg = load_config()
    error = None
    success = None
    if request.method == "POST":
        verify_csrf(cfg)
        key = request.form.get("key", "").strip()
        ok, msg = validate_key(key, current_machine_id=get_machine_id(_DATA_DIR))
        if ok:
            save_license(key)
            success = "Activated — Licensed."
        else:
            error = msg

    return render_template_string(
        ACTIVATE_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, "activate"),
        nav=nav_html(cfg, "activate"),
        error=error,
        success=success,
        licensed_to=load_license(),
        machine_id=get_machine_id(_DATA_DIR),
        device_count=len(cfg["devices"]),
        device_limit=FREE_TIER_DEVICE_LIMIT,
        paypal_url=LICENSE_PURCHASE_URL,
        csrf_token=cfg["csrf_token"]
    )


def verify_csrf(cfg):
    """Abort with 400 if the submitted CSRF token doesn't match. Call at
    the top of every POST route, after load_config()."""
    token = request.form.get("csrf_token", "")
    if not token or token != cfg.get("csrf_token"):
        abort(400, description="Your session expired or the form was tampered with. "
                                "Please refresh the page and try again.")


LOGIN_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — Log in</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: -apple-system, Arial, sans-serif; max-width: 360px; margin: 80px auto; padding: 0 16px; color: #222; }
    h1 { font-size: 1.3rem; }
    .brand-title { font-size: 2.1rem; font-weight: 800; letter-spacing: -0.03em; margin-bottom: 2px;
                   background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                   -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
                   color: #2563eb; }
    .page-heading { font-size: 1.1rem; font-weight: 600; color: #333; margin: 0 0 16px; }
    input[type=text], input[type=password] { width: 100%; padding: 8px; margin: 6px 0 14px; box-sizing: border-box; }
    button { width: 100%; padding: 10px; cursor: pointer; }
    .error { background: #fdeeee; border: 1px solid #f2b8b8; color: #d1242f; border-radius: 8px; padding: 10px 14px; margin-bottom: 12px; font-size: 0.9rem; }
    .app-footer { text-align: center; color: #999; font-size: 0.8rem; margin: 32px 0 8px; padding-top: 12px; border-top: 1px solid #eee; }
  </style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">Log in</h2>
  {% if error %}<div class="error">{{ error }}</div>{% endif %}
  <form method="post">
    <label>Username</label>
    <input type="text" name="username" autofocus required>
    <label>Password</label>
    <input type="password" name="password" required>
    <button type="submit">Log in</button>
  </form>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/login", methods=["GET", "POST"])
def login():
    cfg = load_config()
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        user = next((u for u in cfg.get("users", []) if u["username"] == username), None)
        if user and user.get("password_hash") and \
                check_password_hash(user["password_hash"], password):
            session.clear()
            session["logged_in"] = True
            session["username"] = user["username"]
            session["role"] = user.get("role", "standard")
            session.permanent = True
            next_url = request.args.get("next") or url_for("index")
            return redirect(next_url)
        error = "Invalid username or password."
    return render_template_string(LOGIN_TEMPLATE, error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------
# Dashboard (offline devices only)
# ---------------------------------------------------------------------
DASHBOARD_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">Dashboard</h2>
  <p class="note">Checking every {{ interval }}s. Email alerts: {{ "enabled" if email_enabled else "disabled" }}{% if is_admin %} (<a href="{{ url_for('email_settings') }}">Notification Settings</a>){% endif %}.</p>

  {{ topbar|safe }}
  {{ nav|safe }}

  <div class="summary">
    <div class="stat-card total"><span class="num">{{ total_count }}</span><span class="label">Total Devices</span></div>
    <div class="stat-card online"><span class="num">{{ online_count }}</span><span class="label">Online</span></div>
    <div class="stat-card offline"><span class="num">{{ offline_count }}</span><span class="label">Offline</span></div>
  </div>

  {% if not licensed %}
  <div class="flash">
    <strong>Unlicensed — {{ total_count }} of {{ device_limit }} devices used (free tier).</strong>
    {% if is_admin %}
    Visit the <a href="{{ url_for('activate') }}">License page</a> to unlock unlimited devices.
    {% else %}
    Ask an admin to enter a license key to unlock unlimited devices.
    {% endif %}
  </div>
  {% endif %}

  {% if offline_devices %}
  <div class="offline-banner">
    <strong>{{ offline_devices|length }} device(s) need attention:</strong>
  </div>
  <table>
    <tr><th>Name</th><th>Host</th><th>MAC Address</th><th>Type</th><th>Since</th></tr>
    {% for d in offline_devices %}
    <tr>
      <td>{{ d.name }}</td>
      <td>{{ d.host }}</td>
      <td>{{ d.mac or statuses.get(d.host, {}).get("mac") or "—" }}</td>
      <td>{{ d.type }}</td>
      <td>{{ statuses.get(d.host, {}).get("last_change", "—") }}</td>
    </tr>
    {% endfor %}
  </table>
  {% else %}
  <div class="all-clear">✓ All devices online</div>
  {% endif %}

  <p class="note">This page auto-refreshes every {{ interval }} seconds.</p>
  <script>
    setInterval(() => {
      const active = document.activeElement;
      const isTyping = active && (active.tagName === "INPUT" || active.tagName === "SELECT")
                        && active.type !== "hidden";
      if (!isTyping) {
        location.reload();
      }
    }, {{ interval * 1000 }});
  </script>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/")
@login_required
def index():
    cfg = load_config()
    devices = cfg.get("devices", [])
    with status_lock:
        current_status = dict(status)

    online_count = sum(1 for d in devices if current_status.get(d["host"], {}).get("up"))
    offline_devices = [d for d in devices if current_status.get(d["host"], {}).get("up") is False]
    total_count = len(devices)

    return render_template_string(
        DASHBOARD_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, "dashboard"),
        nav=nav_html(cfg, "dashboard"),
        statuses=current_status,
        interval=cfg.get("check_interval_seconds", 5),
        email_enabled=cfg.get("email", {}).get("enabled", False),
        total_count=total_count,
        online_count=online_count,
        offline_count=len(offline_devices),
        offline_devices=offline_devices,
        licensed=is_licensed(),
        device_limit=FREE_TIER_DEVICE_LIMIT,
        is_admin=session.get("role") == "admin"
    )


# ---------------------------------------------------------------------
# Per-type device page (add / remove / reassign)
# ---------------------------------------------------------------------
TYPE_PAGE_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — {{ type_name }}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">{{ type_name }}</h2>
  <p class="note">Checking every {{ interval }}s.</p>

  {{ topbar|safe }}
  {{ nav|safe }}

  <table>
    <tr><th>Name</th><th>Host</th><th>MAC Address</th><th>Status</th><th>Last Change</th><th>Move to</th><th></th></tr>
    {% for d in devices %}
    <tr data-host="{{ d.host }}">
      <td class="name-cell">
        <span class="view-mode">{{ d.name }}</span>
        <button type="button" class="edit-toggle-btn" onclick="toggleEdit(this)">Edit</button>
        <form class="inline edit-mode" method="post" action="{{ url_for('rename_device') }}" style="display:none;">
          <input type="hidden" name="host" value="{{ d.host }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <input type="text" name="name" value="{{ d.name }}" required
                 style="width:110px;padding:4px;">
          <button type="submit" style="padding:4px 8px;">Save</button>
          <button type="button" class="cancel-btn" onclick="cancelEdit(this)" style="padding:4px 8px;">Cancel</button>
        </form>
      </td>
      <td class="host-cell">
        <span class="view-mode">{{ d.host }}</span>
        <button type="button" class="edit-toggle-btn" onclick="toggleEdit(this)">Edit</button>
        <form class="inline edit-mode" method="post" action="{{ url_for('set_device_host') }}" style="display:none;">
          <input type="hidden" name="old_host" value="{{ d.host }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <input type="text" name="new_host" value="{{ d.host }}" required
                 style="width:110px;padding:4px;">
          <button type="submit" style="padding:4px 8px;">Save</button>
          <button type="button" class="cancel-btn" onclick="cancelEdit(this)" style="padding:4px 8px;">Cancel</button>
        </form>
      </td>
      <td class="mac-cell">
        <span class="view-mode">{{ d.mac or statuses.get(d.host, {}).get("mac") or "—" }}</span>
        <button type="button" class="edit-toggle-btn" onclick="toggleEdit(this)">Edit</button>
        <form class="inline edit-mode" method="post" action="{{ url_for('set_device_mac') }}" style="display:none;">
          <input type="hidden" name="host" value="{{ d.host }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <input type="text" name="mac" value="{{ d.mac or statuses.get(d.host, {}).get('mac') or '' }}"
                 placeholder="Not detected" style="width:110px;font-family:monospace;font-size:0.8rem;padding:4px;">
          <button type="submit" style="padding:4px 8px;">Save</button>
          <button type="button" class="cancel-btn" onclick="cancelEdit(this)" style="padding:4px 8px;">Cancel</button>
        </form>
      </td>
      <td class="status-cell">
        {% set s = statuses.get(d.host) %}
        {% if s is none or s.up is none %}
          <span class="unknown">Checking…</span>
        {% elif s.up %}
          <span class="up">Online</span>
        {% else %}
          <span class="down">Offline</span>
        {% endif %}
      </td>
      <td class="lastchange-cell">{{ statuses.get(d.host, {}).get("last_change", "—") }}</td>
      <td>
        <form class="inline" method="post" action="{{ url_for('move_device') }}">
          <input type="hidden" name="host" value="{{ d.host }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <select name="new_type" onchange="this.form.submit()">
            {% for t in all_types %}
            <option value="{{ t }}" {{ "selected" if t == d.type else "" }}>{{ t }}</option>
            {% endfor %}
          </select>
        </form>
      </td>
      <td>
        <form class="inline" method="post" action="{{ url_for('remove_device') }}">
          <input type="hidden" name="host" value="{{ d.host }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <button class="remove-btn" onclick="return confirm('Remove {{ d.name }}?')">Remove</button>
        </form>
      </td>
    </tr>
    {% endfor %}
    {% if not devices %}
    <tr><td colspan="7" class="note">No devices in this category yet.</td></tr>
    {% endif %}
  </table>

  <p class="note">MAC addresses auto-detect only for devices on your same local network — devices
  behind a router, VLAN, or VPN won't auto-detect (a normal networking limit, not a bug), but you
  can type one in manually and click Save.</p>

  <div class="add-form">
    <form method="post" action="{{ url_for('add_device') }}">
      <input type="hidden" name="type" value="{{ type_name }}">
      <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
      <input type="text" name="name" placeholder="Device name" required>
      <input type="text" name="host" placeholder="IP or hostname" required>
      <input type="text" name="mac" placeholder="MAC address (optional)" style="font-family:monospace;">
      <button type="submit">Add Device to {{ type_name }}</button>
    </form>
  </div>

  {% if import_flash %}<div class="flash">{{ import_flash }}</div>{% endif %}

  <div class="add-form">
    <h2 style="margin-top:0;">Bulk Import from CSV</h2>
    <form method="post" action="{{ url_for('import_devices_csv') }}" enctype="multipart/form-data">
      <input type="hidden" name="type" value="{{ type_name }}">
      <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
      <input type="file" name="csv_file" accept=".csv" required>
      <button type="submit">Import CSV</button>
    </form>
    <p class="note">
      Columns: <code>name, host</code> required — <code>type, mac</code> optional.
      Rows without a <code>type</code> column default to "{{ type_name }}". Unrecognized
      types are created automatically. Duplicate hosts are skipped.
      <a href="{{ url_for('import_csv_template') }}">Download a template CSV</a>.
    </p>
  </div>

  <p class="note">Status updates automatically every {{ interval }} seconds — this page never reloads, so your typing is never interrupted.</p>
  <script>
    function toggleEdit(btn) {
      const td = btn.closest("td");
      td.querySelector(".view-mode").style.display = "none";
      btn.style.display = "none";
      const form = td.querySelector(".edit-mode");
      form.style.display = "inline";
      form.querySelector("input[type=text]").focus();
    }
    function cancelEdit(btn) {
      const td = btn.closest("td");
      td.querySelector(".edit-mode").style.display = "none";
      td.querySelector(".view-mode").style.display = "inline";
      td.querySelector(".edit-toggle-btn").style.display = "inline";
    }

    async function refreshStatuses() {
      try {
        const res = await fetch("{{ url_for('api_statuses') }}");
        if (!res.ok) return;
        const data = await res.json();
        document.querySelectorAll("tr[data-host]").forEach(row => {
          const host = row.getAttribute("data-host");
          const info = data[host];
          if (!info) return;
          const statusCell = row.querySelector(".status-cell");
          const lastChangeCell = row.querySelector(".lastchange-cell");
          if (info.up === null || info.up === undefined) {
            statusCell.innerHTML = '<span class="unknown">Checking…</span>';
          } else if (info.up) {
            statusCell.innerHTML = '<span class="up">Online</span>';
          } else {
            statusCell.innerHTML = '<span class="down">Offline</span>';
          }
          lastChangeCell.textContent = info.last_change || "—";
        });
      } catch (e) {
        // Transient network hiccup — just try again next interval.
      }
    }
    setInterval(refreshStatuses, {{ interval * 1000 }});
  </script>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/api/statuses")
@login_required
def api_statuses():
    with status_lock:
        current_status = dict(status)
    return jsonify(current_status)


@app.route("/type/<path:type_name>")
@login_required
def type_page(type_name):
    cfg = load_config()
    devices = [d for d in cfg["devices"] if d["type"] == type_name]
    with status_lock:
        current_status = dict(status)

    all_types = cfg["types"] + ([UNCATEGORIZED] if type_name == UNCATEGORIZED or
                                 any(d["type"] == UNCATEGORIZED for d in cfg["devices"]) else [])

    return render_template_string(
        TYPE_PAGE_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, type_name),
        nav=nav_html(cfg, type_name),
        type_name=type_name,
        devices=devices,
        statuses=current_status,
        all_types=all_types,
        interval=cfg.get("check_interval_seconds", 5),
        csrf_token=cfg["csrf_token"],
        import_flash=request.args.get("import_flash", "")
    )


@app.route("/devices/import", methods=["POST"])
@login_required
def import_devices_csv():
    cfg = load_config()
    verify_csrf(cfg)
    default_type = request.form.get("type", UNCATEGORIZED).strip() or UNCATEGORIZED

    uploaded_file = request.files.get("csv_file")
    if not uploaded_file or not uploaded_file.filename:
        return redirect(url_for("type_page", type_name=default_type, import_flash="Choose a CSV file first."))

    try:
        raw_bytes = uploaded_file.read()
        text = raw_bytes.decode("utf-8-sig")  # utf-8-sig strips a BOM if present
    except UnicodeDecodeError:
        return redirect(url_for("type_page", type_name=default_type,
                                 import_flash="Couldn't read that file — make sure it's a plain CSV (UTF-8)."))

    existing_hosts = {d["host"] for d in cfg["devices"]}
    new_devices, new_types, stats = parse_devices_csv(text, default_type, existing_hosts, cfg["types"])

    limit = get_device_limit()
    truncated = 0
    if limit is not None:
        remaining_slots = max(0, limit - len(cfg["devices"]))
        if len(new_devices) > remaining_slots:
            truncated = len(new_devices) - remaining_slots
            new_devices = new_devices[:remaining_slots]
            stats["imported"] = len(new_devices)

    cfg["types"].extend(new_types)
    cfg["devices"].extend(new_devices)
    save_config(cfg)

    parts = [f"Imported {stats['imported']} device(s)."]
    if stats["skipped_duplicate"]:
        parts.append(f"Skipped {stats['skipped_duplicate']} duplicate host(s).")
    if stats["skipped_invalid"]:
        parts.append(f"Skipped {stats['skipped_invalid']} row(s) missing a name or host.")
    if new_types:
        parts.append(f"Created new type(s): {', '.join(new_types)}.")
    if truncated:
        parts.append(f"Free tier limited to {limit} devices total — {truncated} row(s) were "
                      f"NOT imported. Enter a license key on the License page to add more.")
    flash = " ".join(parts)

    return redirect(url_for("type_page", type_name=default_type, import_flash=flash))


@app.route("/devices/import/template")
@login_required
def import_csv_template():
    sample = "name,host,type,mac\nFront Desk Printer,192.168.1.50,Printer,\nCore Switch,192.168.1.1,Network,AA:BB:CC:DD:EE:FF\n"
    return sample, 200, {
        "Content-Type": "text/csv",
        "Content-Disposition": "attachment; filename=device_import_template.csv"
    }


@app.route("/add", methods=["POST"])
@login_required
def add_device():
    cfg = load_config()
    verify_csrf(cfg)
    name = request.form.get("name", "").strip()
    host = request.form.get("host", "").strip()
    device_type = request.form.get("type", UNCATEGORIZED).strip() or UNCATEGORIZED
    mac = normalize_mac(request.form.get("mac", ""))

    limit = get_device_limit()
    if limit is not None and len(cfg["devices"]) >= limit:
        return redirect(url_for("type_page", type_name=device_type,
                                 import_flash=f"Free tier is limited to {limit} devices. "
                                               f"Enter a license key on the License page to add more."))

    if name and host and not any(d["host"] == host for d in cfg["devices"]):
        new_device = {"name": name, "host": host, "type": device_type}
        if mac:
            new_device["mac"] = mac
        cfg["devices"].append(new_device)
        save_config(cfg)
    return redirect(url_for("type_page", type_name=device_type))


@app.route("/device/set_mac", methods=["POST"])
@login_required
def set_device_mac():
    cfg = load_config()
    verify_csrf(cfg)
    host = request.form.get("host", "")
    mac = normalize_mac(request.form.get("mac", ""))
    target_type = UNCATEGORIZED
    for d in cfg["devices"]:
        if d["host"] == host:
            if mac:
                d["mac"] = mac
            else:
                d.pop("mac", None)  # empty submission clears the override
            target_type = d["type"]
            break
    save_config(cfg)
    return redirect(url_for("type_page", type_name=target_type))


@app.route("/device/rename", methods=["POST"])
@login_required
def rename_device():
    cfg = load_config()
    verify_csrf(cfg)
    host = request.form.get("host", "")
    new_name = request.form.get("name", "").strip()
    target_type = UNCATEGORIZED
    for d in cfg["devices"]:
        if d["host"] == host:
            if new_name:
                d["name"] = new_name
            target_type = d["type"]
            break
    save_config(cfg)
    return redirect(url_for("type_page", type_name=target_type))


@app.route("/device/set_host", methods=["POST"])
@login_required
def set_device_host():
    cfg = load_config()
    verify_csrf(cfg)
    old_host = request.form.get("old_host", "")
    new_host = request.form.get("new_host", "").strip()
    target_type = UNCATEGORIZED

    device = next((d for d in cfg["devices"] if d["host"] == old_host), None)
    if device:
        target_type = device["type"]

    if not device:
        flash = "Device not found."
    elif not new_host:
        flash = "IP address / hostname cannot be empty."
    elif new_host != old_host and any(d["host"] == new_host for d in cfg["devices"]):
        flash = f'Another device already uses "{new_host}".'
    else:
        if new_host != old_host:
            device["host"] = new_host
            save_config(cfg)
            # Carry over any existing status/MAC data to the new key,
            # rather than losing it and showing "Checking…" again.
            with status_lock:
                if old_host in status:
                    status[new_host] = status.pop(old_host)
        flash = None

    return redirect(url_for("type_page", type_name=target_type, import_flash=flash) if flash
                     else url_for("type_page", type_name=target_type))


@app.route("/remove", methods=["POST"])
@login_required
def remove_device():
    cfg = load_config()
    verify_csrf(cfg)
    host = request.form.get("host", "")
    removed = next((d for d in cfg["devices"] if d["host"] == host), None)
    cfg["devices"] = [d for d in cfg["devices"] if d["host"] != host]
    save_config(cfg)
    with status_lock:
        status.pop(host, None)
    if removed:
        return redirect(url_for("type_page", type_name=removed["type"]))
    return redirect(url_for("index"))


@app.route("/move", methods=["POST"])
@login_required
def move_device():
    cfg = load_config()
    verify_csrf(cfg)
    host = request.form.get("host", "")
    new_type = request.form.get("new_type", UNCATEGORIZED)
    for d in cfg["devices"]:
        if d["host"] == host:
            d["type"] = new_type
    save_config(cfg)
    return redirect(url_for("type_page", type_name=new_type))


# ---------------------------------------------------------------------
# Manage types (create / rename / delete)
# ---------------------------------------------------------------------
MANAGE_TYPES_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — Manage Types</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">Manage Device Types</h2>

  {{ topbar|safe }}
  {{ nav|safe }}

  {% if flash %}
  <div class="flash">{{ flash }}</div>
  {% endif %}

  <table>
    <tr><th>Type</th><th># Devices</th><th>Rename</th><th></th></tr>
    {% for t in types %}
    <tr>
      <td>{{ t }}</td>
      <td>{{ counts.get(t, 0) }}</td>
      <td>
        <form class="inline" method="post" action="{{ url_for('rename_type') }}">
          <input type="hidden" name="old_name" value="{{ t }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <input type="text" name="new_name" placeholder="New name" style="width:140px;">
          <button type="submit">Rename</button>
        </form>
      </td>
      <td>
        <form class="inline" method="post" action="{{ url_for('delete_type') }}">
          <input type="hidden" name="type_name" value="{{ t }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <button class="danger-btn" onclick="return confirm('Delete {{ t }}? Devices in it will move to Uncategorized.')">Delete</button>
        </form>
      </td>
    </tr>
    {% endfor %}
  </table>

  <div class="add-form">
    <form method="post" action="{{ url_for('add_type') }}">
      <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
      <input type="text" name="name" placeholder="New type name" required>
      <button type="submit">Add Type</button>
    </form>
  </div>

  <p class="note">Deleting a type moves its devices to "Uncategorized" — it won't delete the devices themselves.</p>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/types")
@login_required
def manage_types():
    cfg = load_config()
    counts = {}
    for d in cfg["devices"]:
        counts[d["type"]] = counts.get(d["type"], 0) + 1
    flash = request.args.get("flash", "")
    return render_template_string(
        MANAGE_TYPES_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, "manage_types"),
        nav=nav_html(cfg, "manage_types"),
        types=cfg["types"],
        counts=counts,
        flash=flash,
        csrf_token=cfg["csrf_token"]
    )


@app.route("/types/add", methods=["POST"])
@login_required
def add_type():
    cfg = load_config()
    verify_csrf(cfg)
    name = request.form.get("name", "").strip()
    flash = ""
    if not name:
        flash = "Type name can't be empty."
    elif name == UNCATEGORIZED:
        flash = f'"{UNCATEGORIZED}" is reserved.'
    elif name in cfg["types"]:
        flash = f'"{name}" already exists.'
    else:
        cfg["types"].append(name)
        save_config(cfg)
        flash = f'Added type "{name}".'
    return redirect(url_for("manage_types", flash=flash))


@app.route("/types/rename", methods=["POST"])
@login_required
def rename_type():
    cfg = load_config()
    verify_csrf(cfg)
    old_name = request.form.get("old_name", "")
    new_name = request.form.get("new_name", "").strip()
    flash = ""
    if not new_name:
        flash = "New name can't be empty."
    elif new_name in cfg["types"]:
        flash = f'"{new_name}" already exists.'
    elif old_name not in cfg["types"]:
        flash = f'"{old_name}" not found.'
    else:
        cfg["types"] = [new_name if t == old_name else t for t in cfg["types"]]
        for d in cfg["devices"]:
            if d["type"] == old_name:
                d["type"] = new_name
        save_config(cfg)
        flash = f'Renamed "{old_name}" to "{new_name}".'
    return redirect(url_for("manage_types", flash=flash))


@app.route("/types/delete", methods=["POST"])
@login_required
def delete_type():
    cfg = load_config()
    verify_csrf(cfg)
    type_name = request.form.get("type_name", "")
    if type_name in cfg["types"]:
        cfg["types"] = [t for t in cfg["types"] if t != type_name]
        for d in cfg["devices"]:
            if d["type"] == type_name:
                d["type"] = UNCATEGORIZED
        save_config(cfg)
        flash = f'Deleted "{type_name}". Its devices moved to {UNCATEGORIZED}.'
    else:
        flash = f'"{type_name}" not found.'
    return redirect(url_for("manage_types", flash=flash))


# ---------------------------------------------------------------------
# My Account (self-service password change, any logged-in user)
# ---------------------------------------------------------------------
ACCOUNT_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — My Account</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">My Account</h2>
  {{ topbar|safe }}
  {{ nav|safe }}

  {% if flash %}<div class="flash">{{ flash }}</div>{% endif %}

  <p>Logged in as <strong>{{ username }}</strong> ({{ role }})</p>

  <h2>Change Password</h2>
  <form method="post" action="{{ url_for('change_own_password') }}" style="max-width:340px;">
    <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
    <p><label>Current password<br><input type="password" name="current_password" required style="width:100%;padding:6px;"></label></p>
    <p><label>New password<br><input type="password" name="new_password" required style="width:100%;padding:6px;"></label></p>
    <p><label>Confirm new password<br><input type="password" name="confirm_password" required style="width:100%;padding:6px;"></label></p>
    <button type="submit">Update Password</button>
  </form>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/account")
@login_required
def my_account():
    cfg = load_config()
    flash = request.args.get("flash", "")
    return render_template_string(
        ACCOUNT_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, "my_account"),
        nav=nav_html(cfg, "my_account"),
        username=session.get("username"),
        role=session.get("role"),
        csrf_token=cfg["csrf_token"],
        flash=flash
    )


@app.route("/account/change_password", methods=["POST"])
@login_required
def change_own_password():
    cfg = load_config()
    verify_csrf(cfg)
    current_password = request.form.get("current_password", "")
    new_password = request.form.get("new_password", "")
    confirm_password = request.form.get("confirm_password", "")

    user = next((u for u in cfg["users"] if u["username"] == session.get("username")), None)
    flash = ""
    if not user:
        flash = "User not found — please log in again."
    elif not check_password_hash(user["password_hash"], current_password):
        flash = "Current password is incorrect."
    elif not new_password:
        flash = "New password cannot be empty."
    elif new_password != confirm_password:
        flash = "New password and confirmation don't match."
    else:
        user["password_hash"] = generate_password_hash(new_password, method="pbkdf2:sha256")
        save_config(cfg)
        flash = "Password updated."
    return redirect(url_for("my_account", flash=flash))


# ---------------------------------------------------------------------
# Manage Users (admin-only: add, delete, reset any user's password)
# ---------------------------------------------------------------------
USERS_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — Users</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">Manage Users</h2>
  {{ topbar|safe }}
  {{ nav|safe }}

  {% if flash %}<div class="flash">{{ flash }}</div>{% endif %}

  <table>
    <tr><th>Username</th><th>Role</th><th>Reset Password</th><th></th></tr>
    {% for u in users %}
    <tr>
      <td>{{ u.username }}</td>
      <td>{{ u.role }}</td>
      <td>
        {% if u.username == current_username %}
        <span class="note" style="margin:0;">Use <a href="{{ url_for('my_account') }}">My Account</a> to change your own password.</span>
        {% else %}
        <form class="inline" method="post" action="{{ url_for('reset_user_password') }}">
          <input type="hidden" name="username" value="{{ u.username }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <input type="password" name="new_password" placeholder="New password" required style="width:140px;">
          <button type="submit">Reset</button>
        </form>
        {% endif %}
      </td>
      <td>
        <form class="inline" method="post" action="{{ url_for('delete_user') }}">
          <input type="hidden" name="username" value="{{ u.username }}">
          <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
          <button class="danger-btn" onclick="return confirm('Delete user {{ u.username }}?')">Delete</button>
        </form>
      </td>
    </tr>
    {% endfor %}
  </table>

  <div class="add-form">
    <form method="post" action="{{ url_for('add_user') }}">
      <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <select name="role">
        <option value="standard">Standard</option>
        <option value="admin">Admin</option>
      </select>
      <button type="submit">Add User</button>
    </form>
  </div>

  <p class="note">Standard users can manage devices and types. Only admins can manage users
  and notification settings. There must always be at least one admin.</p>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/users")
@admin_required
def manage_users():
    cfg = load_config()
    flash = request.args.get("flash", "")
    return render_template_string(
        USERS_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, "manage_users"),
        nav=nav_html(cfg, "manage_users"),
        users=cfg["users"],
        current_username=session.get("username"),
        csrf_token=cfg["csrf_token"],
        flash=flash
    )


@app.route("/users/add", methods=["POST"])
@admin_required
def add_user():
    cfg = load_config()
    verify_csrf(cfg)
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    role = request.form.get("role", "standard")
    if role not in ("admin", "standard"):
        role = "standard"

    flash = ""
    if not username or not password:
        flash = "Username and password are both required."
    elif any(u["username"] == username for u in cfg["users"]):
        flash = f'User "{username}" already exists.'
    else:
        cfg["users"].append({
            "username": username,
            "password_hash": generate_password_hash(password, method="pbkdf2:sha256"),
            "role": role
        })
        save_config(cfg)
        flash = f'Added user "{username}" ({role}).'
    return redirect(url_for("manage_users", flash=flash))


@app.route("/users/reset_password", methods=["POST"])
@admin_required
def reset_user_password():
    cfg = load_config()
    verify_csrf(cfg)
    username = request.form.get("username", "")
    new_password = request.form.get("new_password", "")

    user = next((u for u in cfg["users"] if u["username"] == username), None)
    flash = ""
    if username == session.get("username"):
        flash = "Use My Account to change your own password (it requires your current password)."
    elif not user:
        flash = f'User "{username}" not found.'
    elif not new_password:
        flash = "Password cannot be empty."
    else:
        user["password_hash"] = generate_password_hash(new_password, method="pbkdf2:sha256")
        save_config(cfg)
        flash = f'Password reset for "{username}".'
    return redirect(url_for("manage_users", flash=flash))


@app.route("/users/delete", methods=["POST"])
@admin_required
def delete_user():
    cfg = load_config()
    verify_csrf(cfg)
    username = request.form.get("username", "")

    admins_remaining = [u for u in cfg["users"] if u["role"] == "admin" and u["username"] != username]
    target = next((u for u in cfg["users"] if u["username"] == username), None)

    flash = ""
    if not target:
        flash = f'User "{username}" not found.'
    elif target["role"] == "admin" and not admins_remaining:
        flash = "Can't delete the last remaining admin account."
    else:
        cfg["users"] = [u for u in cfg["users"] if u["username"] != username]
        save_config(cfg)
        flash = f'Deleted user "{username}".'
        if username == session.get("username"):
            session.clear()
            return redirect(url_for("login"))
    return redirect(url_for("manage_users", flash=flash))


# ---------------------------------------------------------------------
# Notification Settings (admin-only, replaces the old Tkinter screen)
# ---------------------------------------------------------------------
EMAIL_SETTINGS_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — Notification Settings</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">Notification Settings</h2>
  {{ topbar|safe }}
  {{ nav|safe }}

  {% if flash %}<div class="flash">{{ flash }}</div>{% endif %}

  <form method="post" action="{{ url_for('save_email_settings') }}" style="max-width:420px;">
    <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
    <p><label><input type="checkbox" name="enabled" {{ "checked" if email.enabled else "" }}>
       Send me an email when a device goes offline</label></p>
    <p><label>SMTP server<br><input type="text" name="smtp_server" value="{{ email.smtp_server }}" style="width:100%;padding:6px;"></label></p>
    <p><label>SMTP port<br><input type="text" name="smtp_port" value="{{ email.smtp_port }}" style="width:100%;padding:6px;"></label></p>
    <p><label>Your email<br><input type="text" name="username" value="{{ email.username }}" style="width:100%;padding:6px;"></label></p>
    <p><label>App password<br><input type="password" name="password" value="{{ email.password }}" style="width:100%;padding:6px;"></label></p>
    <p><label>Send alerts to<br><input type="text" name="to_addr" value="{{ email.to_addr }}" style="width:100%;padding:6px;"></label></p>
    <p><label>Alert after a device has been offline for (minutes)<br>
       <input type="text" name="alert_delay_minutes" value="{{ alert_delay_minutes }}" style="width:100%;padding:6px;"></label></p>
    <p class="note">Waiting a few minutes before alerting avoids emails for brief blips.
    Use 0 to alert immediately on the first missed ping.</p>
    <p class="note">For Gmail, use an App Password (not your normal password) — create one at
    myaccount.google.com/apppasswords</p>
    <button type="submit">Save</button>
  </form>

  <form method="post" action="{{ url_for('test_email_settings') }}" style="max-width:420px;margin-top:12px;">
    <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
    <input type="hidden" name="smtp_server" value="{{ email.smtp_server }}">
    <input type="hidden" name="smtp_port" value="{{ email.smtp_port }}">
    <input type="hidden" name="username" value="{{ email.username }}">
    <input type="hidden" name="password" value="{{ email.password }}">
    <input type="hidden" name="to_addr" value="{{ email.to_addr }}">
    <button type="submit">Send Test Email (using saved settings above)</button>
  </form>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/settings/email")
@admin_required
def email_settings():
    cfg = load_config()
    flash = request.args.get("flash", "")
    alert_delay_minutes = round(cfg.get("offline_alert_delay_seconds", 60) / 60, 1)
    if alert_delay_minutes == int(alert_delay_minutes):
        alert_delay_minutes = int(alert_delay_minutes)
    return render_template_string(
        EMAIL_SETTINGS_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, "email_settings"),
        nav=nav_html(cfg, "email_settings"),
        email=cfg.get("email", {}),
        alert_delay_minutes=alert_delay_minutes,
        csrf_token=cfg["csrf_token"],
        flash=flash
    )


@app.route("/settings/email/save", methods=["POST"])
@admin_required
def save_email_settings():
    cfg = load_config()
    verify_csrf(cfg)
    try:
        port = int(request.form.get("smtp_port", "587"))
    except ValueError:
        port = 587
    try:
        alert_delay_minutes = float(request.form.get("alert_delay_minutes", "1"))
        alert_delay_minutes = max(0, alert_delay_minutes)
    except ValueError:
        alert_delay_minutes = 1
    cfg["offline_alert_delay_seconds"] = int(alert_delay_minutes * 60)
    cfg["email"] = {
        "enabled": request.form.get("enabled") == "on",
        "smtp_server": request.form.get("smtp_server", "").strip(),
        "smtp_port": port,
        "username": request.form.get("username", "").strip(),
        "password": request.form.get("password", "").strip().replace(" ", ""),
        "from_addr": request.form.get("username", "").strip(),
        "to_addr": request.form.get("to_addr", "").strip(),
        "notify_on_recovery": True,
    }
    save_config(cfg)
    return redirect(url_for("email_settings", flash="Settings saved."))


@app.route("/settings/email/test", methods=["POST"])
@admin_required
def test_email_settings():
    cfg = load_config()
    verify_csrf(cfg)
    try:
        port = int(request.form.get("smtp_port", "587"))
    except ValueError:
        port = 587
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip().replace(" ", "")
    to_addr = request.form.get("to_addr", "").strip()
    smtp_server = request.form.get("smtp_server", "").strip()

    if not username or not password or not to_addr:
        return redirect(url_for("email_settings", flash="Fill in and save email, password, and recipient first."))

    try:
        msg = MIMEText("This is a test email from DeviceKnock. "
                        "If you received this, notifications are working.")
        msg["Subject"] = "DeviceKnock — Test Email"
        msg["From"] = username
        msg["To"] = to_addr
        with smtplib.SMTP(smtp_server, port, timeout=10) as server:
            server.starttls()
            server.login(username, password)
            server.sendmail(username, [to_addr], msg.as_string())
        flash = "Test email sent — check your inbox."
    except Exception as e:
        flash = f"Failed to send: {e}"
    return redirect(url_for("email_settings", flash=flash))


# ---------------------------------------------------------------------
# Backup & Restore (admin-only)
# ---------------------------------------------------------------------
BACKUP_TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>DeviceKnock — Backup &amp; Restore</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>{{ base_style }}</style>
</head>
<body>
  <h1 class="brand-title">DeviceKnock</h1>
  <h2 class="page-heading">Backup &amp; Restore</h2>
  {{ topbar|safe }}
  {{ nav|safe }}

  {% if flash %}<div class="flash">{{ flash }}</div>{% endif %}

  <h2>Save Config</h2>
  <p class="note">Downloads everything — devices, types, users, and notification
  settings — as one file. Keep it somewhere safe; it contains password hashes and
  your SMTP credentials, so treat it like any other sensitive backup.</p>
  <form method="get" action="{{ url_for('backup_download') }}">
    <button type="submit">Download Config Backup</button>
  </form>

  <h2>Restore Config</h2>
  <p class="note">Replaces everything currently configured with what's in the
  backup file — devices, types, users, settings, all of it. This can't be undone
  except by restoring a different backup. If the backup has different login
  credentials than what you're using now, you'll be logged out and need to sign
  in again with whatever's in the restored file.</p>
  <form method="post" action="{{ url_for('backup_restore') }}" enctype="multipart/form-data"
        onsubmit="return confirm('This will replace ALL current devices, types, users, and settings. Continue?');">
    <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
    <input type="file" name="backup_file" accept=".json" required>
    <button type="submit" class="danger-btn">Restore from Backup</button>
  </form>
  <footer class="app-footer">Created by: John Krussaniotakis Sr.<br>Email: support@deviceknock.com</footer>
</body>
</html>
"""


@app.route("/backup")
@admin_required
def backup_page():
    cfg = load_config()
    flash = request.args.get("flash", "")
    return render_template_string(
        BACKUP_TEMPLATE,
        base_style=BASE_STYLE,
        topbar=topbar_html(cfg, "backup_page"),
        nav=nav_html(cfg, "backup_page"),
        csrf_token=cfg["csrf_token"],
        flash=flash
    )


@app.route("/backup/download")
@admin_required
def backup_download():
    cfg = load_config()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"device_monitor_backup_{timestamp}.json"
    return json.dumps(cfg, indent=2), 200, {
        "Content-Type": "application/json",
        "Content-Disposition": f"attachment; filename={filename}"
    }


@app.route("/backup/restore", methods=["POST"])
@admin_required
def backup_restore():
    cfg = load_config()
    verify_csrf(cfg)

    uploaded_file = request.files.get("backup_file")
    if not uploaded_file or not uploaded_file.filename:
        return redirect(url_for("backup_page", flash="Choose a backup file first."))

    try:
        raw_bytes = uploaded_file.read()
        restored = json.loads(raw_bytes.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return redirect(url_for("backup_page", flash="That file isn't valid JSON — restore cancelled."))

    required_keys = ["devices", "types", "users"]
    if not isinstance(restored, dict) or not all(
            k in restored and isinstance(restored[k], list) for k in required_keys):
        return redirect(url_for("backup_page",
                                 flash="That doesn't look like a DeviceKnock backup file "
                                       "(missing devices/types/users) — restore cancelled."))

    save_config(restored)
    return redirect(url_for("backup_page", flash="Config restored successfully."))


def set_password_cli():
    cfg = load_config()
    usernames = [u["username"] for u in cfg["users"]]
    print(f"Existing users: {', '.join(usernames)}")
    target_username = input("Username to set/reset (new name creates a new admin user): ").strip()
    if not target_username:
        print("Username cannot be empty. Aborted.")
        sys.exit(1)
    password = getpass.getpass("New password: ")
    confirm = getpass.getpass("Confirm password: ")
    if not password:
        print("Password cannot be empty. Aborted.")
        sys.exit(1)
    if password != confirm:
        print("Passwords did not match. Aborted.")
        sys.exit(1)

    existing = next((u for u in cfg["users"] if u["username"] == target_username), None)
    new_hash = generate_password_hash(password, method="pbkdf2:sha256")
    if existing:
        existing["password_hash"] = new_hash
        print(f"Password updated for existing user '{target_username}' (role: {existing['role']}).")
    else:
        cfg["users"].append({"username": target_username, "password_hash": new_hash, "role": "admin"})
        print(f"Created new admin user '{target_username}'.")
    save_config(cfg)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DeviceKnock")
    parser.add_argument("--set-password", action="store_true",
                         help="Set or reset the admin username/password, then exit.")
    parser.add_argument("--init-only", action="store_true",
                         help="Create config.json and the initial admin password, then exit "
                              "without starting the server. Used by installer scripts.")
    args = parser.parse_args()

    if args.set_password:
        set_password_cli()
        sys.exit(0)

    if args.init_only:
        load_config()
        sys.exit(0)

    cfg = load_config()  # ensure config.json exists, prints initial password if new
    t = threading.Thread(target=monitor_loop, daemon=True)
    t.start()

    host = cfg.get("web_host", "0.0.0.0")
    port = cfg.get("web_port", 5050)

    try:
        from waitress import serve
        print(f"Starting production server (waitress) on http://{host}:{port}")
        serve(app, host=host, port=port, threads=8)
    except ImportError:
        print("NOTE: 'waitress' isn't installed — falling back to Flask's built-in "
              "development server, which isn't recommended for production use.\n"
              "Install it with: pip install waitress")
        app.run(host=host, port=port, threaded=True)
